export const RequestStatus = {
    NOT_STARTED: 'NOT_STARTED',
    STARTED: 'STARTED',
    SUCCESS: 'SUCCESS',
    FAILURE: 'FAILURE',
}