import { ParkingTypes } from '../../action_types'

export const getDataParkingRequest = () => {
    return {
        type: ParkingTypes.GET_DATA_PARKING_REQUEST,
    }
}

export const getDataParkingSuccess = (payload) => {
    return {
        type: ParkingTypes.GET_DATA_PARKING_SUCCESS,
        payload,
    }
}

export const getDataParkingFailure = (error) => {
    return {
        type: ParkingTypes.GET_DATA_PARKING_FAILURE,
        error,
    }
}