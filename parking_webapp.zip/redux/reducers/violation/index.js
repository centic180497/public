import * as types from '../../action_types/search_violation'
const INITIAL_STATE={
    showInfowindow:{
        lat:null,
        lng:null
    }
}
 const reducer_search_violation=(state=INITIAL_STATE,action)=>{
    switch(action.type){
        case types.SHOW_INFOWINDOW_VIOLATION:
            return{
                ...state,
                showInfowindow:{
                    lat:action.payload.lat,
                    lng:action.payload.lng
                }
            }
        case types.CLEAR_INFOWINDOW_VIOLATION:
            return{
                ...state,
                showInfowindow:{
                    lat:null,
                    lng:null
                }
            }
        default:
            return state
    }
}
export default  reducer_search_violation