import { combineReducers } from "redux";

// import map from "./map";
import searchViolation from './violation'

export default combineReducers({
  // map,
  searchViolation
});
