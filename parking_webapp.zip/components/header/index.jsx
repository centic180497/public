import React from "react";
import { makeStyles, Paper, Typography, Button } from "@material-ui/core";
import img from '../../public/assets/logo.png'
let backgroundActive = "linear-gradient(45deg, #E91E63, #202e7d)";
const ManageNavbar = () => {
  //   const classes = makeStyles();
  const classes = useStyles();
  //   const match = useRouteMatch();
  //   const history = useHistory();

  return (
    <Paper square className={classes.header}>
     
            <img src={img}></img>
    
      {/* <Typography component="h2" className={classes.title}>
        Sở Giao Thông Đà Nẵng
      </Typography> */}
      <div className={classes.menu}>
        <Button className={classes.button}>Trang Chủ</Button>
        <Button className={classes.button}>Vi Phạm</Button>
        <Button className={classes.button}>Thông Báo</Button>
      </div>
    </Paper>
  );
};

export default ManageNavbar;
const useStyles = makeStyles((theme) => ({
    header: {
        height: 70,
        zIndex: 1,
        // background: '#0a0944',
        background: '#FFFFFF',
        color: 'white',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '0 50px',
    },

    button: {
        position: 'relative',
        color: 'black',
        textTransform: 'capitalize',
        marginRight: 22,
        transition: '.2s ease-in-out',
        '&.active': {
            background: 'white',
            color: 'black',
            '&::after': {
                opacity: '1',
                visibility: 'visible',
                width: '100%',
            },
        },

        '&::after': {
            content: '""',
            position: 'absolute',
            width: 0,
            height: 3,
            background: 'black',
            bottom: 0,
            left: 0,
            opacity: 0,
            transition: '.2s ease-in-out',
            visibility: 'hidden',
        },
        '&::before': {
            content: '""',
            position: 'absolute',
            width: 0,
            height: '100%',
            background: 'black',
            bottom: 0,
            left: 0,
            opacity: 0,
            transition: '.2s ease-in-out',
            visibility: 'hidden',
            zIndex: -1,
            borderRadius: 4
        },
        '&:hover:after': {
            opacity: 1,
            visibility: 'visible',
            width: '100%',
        },
        '&:hover': {
            color: 'black',
        },
        '&:hover:before': {
            opacity: 1,
            visibility: 'visible',
            width: '100%',
        },
    },

    title: {
        fontWeight: 500,
        textTransform: 'uppercase',
        fontSize: 18,
    },
}))
