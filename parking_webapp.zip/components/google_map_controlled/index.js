import {connect} from 'react-redux'
import MapOptions from './google_map_controlled'

export default connect()(MapOptions)