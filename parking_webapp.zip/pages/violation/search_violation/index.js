import SearchTable from './search_violation'

export default (SearchTable)