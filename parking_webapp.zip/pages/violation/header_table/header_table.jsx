import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { TableHead, TableRow, TableCell, Checkbox } from "@material-ui/core";
import TableContainer from "@material-ui/core/TableContainer";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import { DataGrid } from "@material-ui/data-grid";
import { useDemoData } from "@material-ui/x-grid-data-generator";
import Pagination from "@material-ui/lab/Pagination";
import img from '../../../public/assets/violation.jpg'
function HeaderTable(props) {
  const classes = useStyles();
  const { listViolation, updateSelectViolation, violationSelected } = props;

  // const handleSelectAllClick = (e) => {
  //     if (e.target.checked) {
  //         const newSelected = listViolation && listViolation.map((n) => n.id)
  //         updateSelectViolation(newSelected)
  //         return
  //     }
  //     updateSelectViolation([])
  // }
  const { data } = useDemoData({
    dataSet: "Commodity",
    rowLength: 100,
    maxColumns: 6,
  });
  const vehicle = [
    {
      lat: "16.04319399907483",
      lng: "108.21515312158203",
      image: "",
      vehicle: "43A-11491",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat: "16.075300",
      lng: "108.223558",
      image: "",
      vehicle: "43A-11492",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
    },
    {
      lat: "16.077707",
      lng: "108.223231",
      image: "",
      vehicle: "43A-11493",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat: "16.081844",
      lng: "108.222743",
      image: "",
      vehicle: "43A-11494",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat: "16.074250",
      lng: "108.223653",
      image: "",
      vehicle: "43A-11495",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    // {
    //   lat: "16.074252",
    //   lng: "108.223653",
    //   image: "",
    //   vehicle: "43A-11496",
    //   type: "Dừng xe nơi cấm dừng cấm đỗ",
    //   date: "31/10/2020",
    //   stress: "Đường Trần phú,Quận hải châu",
    //   Processingunit: "Sở giao thông vận tải đà nẵng",
    //   typeVehicle: "Ô tô",
    // },
    // {
    //   lat: "16.074253",
    //   lng: "108.223653",
    //   image: "",
    //   vehicle: "43A-11497",
    //   type: "Dừng xe nơi cấm dừng cấm đỗ",
    //   date: "31/10/2020",
    //   stress: "Đường Trần phú,Quận hải châu",
    //   Processingunit: "Sở giao thông vận tải đà nẵng",
    //   typeVehicle: "Ô tô",
    // },
    // {
    //   lat: "16.074254",
    //   lng: "108.223653",
    //   image: "",
    //   vehicle: "43A-11498",
    //   type: "Dừng xe nơi cấm dừng cấm đỗ",
    //   date: "31/10/2020",
    //   stress: "Đường Trần phú,Quận hải châu",
    //   Processingunit: "Sở giao thông vận tải đà nẵng",
    //   typeVehicle: "Ô tô",
    // },
    // {
    //   lat: "16.074255",
    //   lng: "108.223653",
    //   image: "",
    //   vehicle: "43A-11499",
    //   type: "Dừng xe nơi cấm dừng cấm đỗ",
    //   date: "31/10/2020",
    //   stress: "Đường Trần phú,Quận hải châu",
    //   Processingunit: "Sở giao thông vận tải đà nẵng",
    //   typeVehicle: "Ô tô",
    // },
  ];
  // const columns = [
  //   { field: 'id', headerName: 'ID', width: 70 },
  //   { field: 'firstName', headerName: 'First name', width: 130 },
  //   { field: 'lastName', headerName: 'Last name', width: 130 },
  //   {
  //     field: 'age',
  //     headerName: 'Age',
  //     type: 'number',
  //     width: 90,
  //   },
  //   {
  //     field: 'fullName',
  //     headerName: 'Full name',
  //     description: 'This column has a value getter and is not sortable.',
  //     sortable: false,
  //     width: 160,
  //     valueGetter: (params) =>
  //       `${params.getValue('firstName') || ''} ${params.getValue('lastName') || ''}`,
  //   },
  // ];
  const itemActive = (e, historyRow) => {
    props.showInfowindow(historyRow);
  };
  console.log(props.Infowindow);

  return (
    <>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            {/* <TableCell>
                    <Checkbox
                        size="small"
                        color="primary"
                        // indeterminate={violationSelected.length > 0 && violationSelected.length < listViolation.length}
                        // checked={listViolation.length > 0 && violationSelected.length === listViolation.length}
                        // onChange={handleSelectAllClick}
                    />
                </TableCell> */}
            <TableCell  align="center"> Ảnh </TableCell>
            <TableCell  align="center"> Biển số </TableCell>
            <TableCell  align="center">Lỗi vi phạm </TableCell>
            {/* <TableCell align="center"> Ngày vi phạm </TableCell> */}
            <TableCell  align="center"> Tuyến đường vi phạm </TableCell>
            {/* <TableCell align="center"> Loại Phương Tiện </TableCell> */}
          </TableRow>
        </TableHead>
        <TableBody>
          {vehicle.map((historyRow) => (
            <TableRow
              onClick={(e) => itemActive(e, historyRow)}
              className={
                props.Infowindow.lat === historyRow.lat &&
                props.Infowindow.lng === historyRow.lng
                  ? classes.tablerow
                  : classes.untablerow
              }
            >
              <TableCell align="center">
              <img src={img} className={classes.imagepopup}></img>
              </TableCell>
              <TableCell  align="center">
                <p>{historyRow.vehicle}</p>
      
                <p> <b>Loại Phương Tiện :</b>{historyRow.typeVehicle}</p>
              </TableCell>
              <TableCell  align="center">
                <p>{historyRow.type}</p>
                <p> <b>Ngày vi phạm:</b>{historyRow.date}</p>
              </TableCell>
              {/* <TableCell align="center">{historyRow.date}</TableCell> */}
              <TableCell  align="center">{historyRow.stress}</TableCell>
              {/* <TableCell align="center">{historyRow.Processingunit}</TableCell> */}
              {/* <TableCell align="center">{historyRow.typeVehicle}</TableCell> */}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div className={classes.pagination}>
        <Pagination
          count={100000}
          showFirstButton
          showLastButton
          // onChange={onChange}
          siblingCount={1}
        />
      </div>
    </>
  );
}

export default HeaderTable;

const useStyles = makeStyles((theme) => ({
  table: {
    width: "100%",
  },
  pagination: {
    width: "100%",
    display: "flex",
    padding: "10px 0",
    justifyContent: "center",
    boxShadow: "5px 2px 6px 3px #bbbbbb78",
  },
  tablerow: {
    background: "#00000014",
    // display: 'flex',
    cursor: "pointer",
    // marginBottom: 5,
  },
  untablerow: {
    cursor: "pointer",
  },
  imagepopup:{
    width:130
  }
}));
