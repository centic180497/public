import React, { useState, useRef } from "react";
import { Marker, InfoWindow } from "react-google-maps";
import iconmk from "../../../../public/assets/ic_parking.png";
import { makeStyles } from "@material-ui/core/styles";
import image from "../../../../public/assets/violation.jpg";
import Typography from "@material-ui/core/Typography";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogActions from "@material-ui/core/DialogActions";
import { TableHead, TableRow, TableCell, Checkbox } from "@material-ui/core";
import TableContainer from "@material-ui/core/TableContainer";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import Button from "@material-ui/core/Button";
import SendIcon from "@material-ui/icons/Send";
import Slider from "react-slick";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import NavigateBeforeIcon from "@material-ui/icons/NavigateBefore";

function MarkerComponent(props, ref) {
  var iconmarker = {
    url: iconmk,
    scaledSize: new window.google.maps.Size(40, 40),
  };
  const classes = useStyles();
  const [opendialog, setOpendialog] = useState(false);
  const dialogtable = () => {
    setOpendialog(true);
  };
  const handleClose = () => {
    setOpendialog(false);
  };
  const handleToggle = () => {
    props.clearInfowindow();
  };
  //   const settings = {
  //     dots: true,
  //     infinite: true,
  //     speed: 500,
  //     slidesToShow: 1,
  //     slidesToScroll: 1
  //   };
  const settings = {
    dots: true,
    slidesToShow: 1,
  };
  //   const handleref = useRef();
  //   console.log(handleref.current);

  //   const next =(e,handleref)=>{

  //     handleref.slickNext()
  //   }
  return (
    <Marker
      position={{
        lat: parseFloat(props.marker.lat),
        lng: parseFloat(props.marker.lng),
      }}
      icon={iconmarker}
    >
      {props.Infowindow.lat === props.lat &&
      props.Infowindow.lng === props.lng ? (
        <InfoWindow onCloseClick={() => handleToggle()}>
          <div className={classes.Info}>
            <div className={classes.slidercontent}>
              <Slider {...settings} className={classes.slider}>
                <div>
                  <img className={classes.imgpopup} src={image}></img>
                </div>
                <div>
                  <img className={classes.imgpopup} src={image}></img>
                </div>
                <div>
                  <img className={classes.imgpopup} src={image}></img>
                </div>
              </Slider>
              <div class={classes.slidebutton}>
                <button className={classes.next}>
                  <NavigateBeforeIcon />
                </button>
                <button className={classes.prev}>
                  <NavigateNextIcon />
                </button>
              </div>
            </div>
            <div className={classes.titlepopup}>
              <Typography variant="subtitle1">
                <b className={classes.title}>Tuyến đường:</b>
                {props.marker.stress}
              </Typography>
              <Typography variant="subtitle1">
                <b className={classes.title}>Biển số:</b>
                {props.marker.vehicle}
              </Typography>
              <Typography variant="subtitle1">
                <b className={classes.title}>Ngày vi phạm:</b>
                {props.marker.date}
              </Typography>
              <div
                //   className={classes.infotitlepopup}
                onClick={() => dialogtable()}
              >
                <Button
                  variant="outlined"
                  color="primary"
                  className={classes.infotitlepopup}
                >
                  chi tiết <SendIcon className={classes.icon} />
                </Button>
                {/* <a className={classes.infotitlepopup}>thông tin chi tiết...</a> */}
              </div>
            </div>
          </div>
        </InfoWindow>
      ) : null}
      {opendialog ? (
        <Dialog
          open={opendialog}
          onClose={() => handleClose()}
          aria-labelledby="form-dialog-title"
          className={classes.dialog}
        >
          <DialogTitle id="form-dialog-title">Chi tiết vi phạm</DialogTitle>
          <Table className={classes.table} aria-label="simple table">
            {/* <TableHead> */}
            <TableRow>
              <TableCell> Ảnh </TableCell>
              <TableCell component="th" scope="row">
                <img src={image} className={classes.imagepopup}></img>
                {/* {props.marker.image} */}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell> Loại vi phạm </TableCell>
              <TableCell component="th" scope="row">
                {props.marker.type}
                {/* {props.marker.image} */}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell> Ngày vi phạm </TableCell>
              <TableCell component="th" scope="row">
                {props.marker.date}
                {/* {props.marker.image} */}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell> Tuyến đường vi phạm </TableCell>
              <TableCell component="th" scope="row">
                {props.marker.stress}
                {/* {props.marker.image} */}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell> Loại phương tiện </TableCell>
              <TableCell component="th" scope="row">
                {props.marker.typeVehicle}
                {/* {props.marker.image} */}
              </TableCell>
            </TableRow>
            {/* </TableHead> */}
          </Table>
          {/* <DialogActions>
              <Button onClick={handleClose} color="primary">
                Cancel
              </Button>
              <Button onClick={handleClose} color="primary">
                Subscribe
              </Button>
            </DialogActions> */}
        </Dialog>
      ) : null}
    </Marker>
  );
}
export default MarkerComponent;
const useStyles = makeStyles((theme) => ({
  Info: {},
  slider: {
    width: 450,
  },
  slidercontent: {
    width: "100%",
    position: "relative",
  },
  slidebutton: {
    position: "absolute",
    top: "50%",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
  },
  imgpopup: {
    width: "450px",
  },
  title: {
    fontWeight: 500,
  },
  dialog: {
    height: "100%",
    width: "100%",
  },
  imagepopup: {
    width: 350,
  },
  infotitlepopup: {
    cursor: "pointer",
    color: "#3c16ce",
    float: "right",
    marginTop: "-40px",
  },
  icon: {
    fontSize: 14,
    marginLeft: 5,
  },
  titlepopup: {
    padding: 20,
  },
  next: {
    borderRadius: "50%",
    transition: "background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
    color: "white",
    cursor: "pointer",
    backgroundColor: "initial",
    '&:hover': {
        color:'black',
        backgroundColor:'white'
    },
  },
  prev: {
    borderRadius: "50%",
    transition: "background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
    color: "white",
    cursor: "pointer",
    backgroundColor: "initial",
    '&:hover': {
        color:'black',
        backgroundColor:'white'
    },
  },
}));
