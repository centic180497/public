import MapOptions from "../../../components/google_map_controlled";
import MarkerComponent from './marker'
import { GoogleMap ,Marker} from "react-google-maps";
function MapViolation(props) {
  const vehicle = [
    {
      lat:'16.04319399907483',
      lng:'108.21515312158203',
      image: "",
      vehicle: "43A-11491",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.075300',
      lng:'108.223558',
      image: "",
      vehicle: "43A-11492",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
    },
    {
      lat:'16.077707',
      lng:'108.223231',
      image: "",
      vehicle: "43A-11493",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.081844',
      lng:'108.222743',
      image: "",
      vehicle: "43A-11494",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.074250',
      lng:'108.223653',
      image: "",
      vehicle: "43A-11495",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.074252',
      lng:'108.223653',
      image: "",
      vehicle: "43A-11496",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.074253',
      lng:'108.223653',
      image: "",
      vehicle: "43A-11497",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.074254',
      lng:'108.223653',
      image: "",
      vehicle: "43A-11498",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
    {
      lat:'16.074255',
      lng:'108.223653',
      image: "",
      vehicle: "43A-11499",
      type: "Dừng xe nơi cấm dừng cấm đỗ",
      date: "31/10/2020",
      stress: "Đường Trần phú,Quận hải châu",
      Processingunit: "Sở giao thông vận tải đà nẵng",
      typeVehicle: "Ô tô",
    },
  ];
  return (
    <MapOptions>
      <GoogleMap
        zoom={13}
        defaultCenter={{ lat: 16.04319399907483, lng: 108.21515312158203 }}
        // onClick={(e) => handleMap(e)}
      >
        {vehicle.length
          ? vehicle.map((marker, index) => {
              return (
                <MarkerComponent
                  marker={marker}
                  key={index}
                  // id={marker.id}
                  lat={marker.lat}
                  lng={marker.lng}
                />
              );
            })
          : null}
      </GoogleMap>
    </MapOptions>
  );
}
export default MapViolation
