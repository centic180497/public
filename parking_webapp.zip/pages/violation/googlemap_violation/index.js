import MapViolation from './googlemap_violation'
export default (MapViolation)