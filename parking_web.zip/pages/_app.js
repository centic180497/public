import { Provider } from "react-redux";
import Head from "next/head";

import store from "../redux/stores";
import "../public/global.css";

function MyApp({ Component, pageProps }) {

  return (
    <Provider store={store}>
       <Head>
        <title>Create Next App</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Component {...pageProps} />
    </Provider>
  );
}

export default MyApp;
