export default function Table() {
  return (
    <p></p>
  );
}
