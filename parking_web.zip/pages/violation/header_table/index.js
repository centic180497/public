// import { connect } from 'react-redux'

import HeaderTable from './header_table'

export default (HeaderTable)
