import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import { TableHead, TableRow, TableCell, Checkbox } from '@material-ui/core'

function HeaderTable(props) {
    const classes = useStyles()
    const { listViolation, updateSelectViolation, violationSelected } = props

    // const handleSelectAllClick = (e) => {
    //     if (e.target.checked) {
    //         const newSelected = listViolation && listViolation.map((n) => n.id)
    //         updateSelectViolation(newSelected)
    //         return
    //     }
    //     updateSelectViolation([])
    // }
    return (
        <TableHead>
            <TableRow>
                <TableCell>
                    <Checkbox
                        size="small"
                        color="primary"
                        // indeterminate={violationSelected.length > 0 && violationSelected.length < listViolation.length}
                        // checked={listViolation.length > 0 && violationSelected.length === listViolation.length}
                        // onChange={handleSelectAllClick}
                    />
                </TableCell>
                <TableCell> Ảnh </TableCell>
                <TableCell> Biển số </TableCell>
                <TableCell> Loại xe </TableCell>
                <TableCell> Loại vi phạm </TableCell>
                <TableCell> Thời gian </TableCell>
                <TableCell> Địa điểm </TableCell>
                <TableCell> Trạng thái </TableCell>
            </TableRow>
        </TableHead>
    )
}

export default HeaderTable

const useStyles = makeStyles((theme) => ({}))
