import Table from './table'
import ManageNavbar from '../../components/header/index'
import HeaderTable from './header_table'
export default function Violation() {
  return (
      
    <div>
        <ManageNavbar/> 
       <HeaderTable />
    </div>
  );
}
