import SiteMap from "../components/site_map";

export default function Home() {
  return (
      <SiteMap />
  );
}
