import { connect } from 'react-redux'
import Map from './google_map'

export default connect()(Map)
