import React from 'react'

import MapOptions from '../google_map_controlled'

const Map = (props) => {

    return (
        <MapOptions>
            
        </MapOptions>
    )
}

export default Map
